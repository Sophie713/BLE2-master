package com.example.sophie.ble2.ui;

/**
 * Created by Sophie on 3/2/2018.
 */

public class Constants {
    public static final String TAG = "BLE2";
    public static final String FIND = "Find BLE Devices";
    public static final String STOP_SCANNING = "Stop Scanning";
    public static final String SCANNING = "Scanning";
    //filter device I want to scan for //white box: A0:E6:F8:77:AB:28 estimote: F6:9F:99:06:A7:ED phone: 00:20:CB:A1:30:67
    //TO-DO read this from somewhere
    public static final String monitored_device ="2f234454-cf6d-4a0f-adf2-f4911ba9ffa6";
}
